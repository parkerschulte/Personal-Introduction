namespace Latin_Translator_App
{
    public partial class LatinTranslator : Form
    {
        public LatinTranslator()
        {
            InitializeComponent();
        }

        private void autBttn_upLbl_Click(object sender, EventArgs e)
        {
            Label lbl = new Label();
            lbl.Text = "up";
            lbl.Location = new System.Drawing.Point(50, 50);
            lbl.AutoSize = true;
            this.Controls.Add(lbl);
        }

        private void desBttn_dwnLbl_Click(object sender, EventArgs e)
        {
            Label lbl = new Label();
            lbl.Text = "down";
            lbl.Location = new System.Drawing.Point(150, 50);
            lbl.AutoSize = true;
            this.Controls.Add(lbl);
        }

        private void medBttn_cenLbl_Click(object sender, EventArgs e)
        {
            Label lbl = new Label();
            lbl.Text = "center";
            lbl.Location = new System.Drawing.Point(300, 50);
            lbl.AutoSize = true;
            this.Controls.Add(lbl);
        }
    }
}
