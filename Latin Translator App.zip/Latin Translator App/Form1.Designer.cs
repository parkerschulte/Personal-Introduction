﻿namespace Latin_Translator_App
{
    partial class LatinTranslator
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            autBttn_upLbl = new Button();
            desBttn_dwnLbl = new Button();
            medBttn_cenLbl = new Button();
            SuspendLayout();
            // 
            // autBttn_upLbl
            // 
            autBttn_upLbl.Location = new Point(0, 0);
            autBttn_upLbl.Name = "autBttn_upLbl";
            autBttn_upLbl.Size = new Size(94, 29);
            autBttn_upLbl.TabIndex = 0;
            autBttn_upLbl.Text = "autem";
            autBttn_upLbl.UseVisualStyleBackColor = true;
            autBttn_upLbl.Click += autBttn_upLbl_Click;
            // 
            // desBttn_dwnLbl
            // 
            desBttn_dwnLbl.Location = new Point(160, 0);
            desBttn_dwnLbl.Name = "desBttn_dwnLbl";
            desBttn_dwnLbl.Size = new Size(94, 29);
            desBttn_dwnLbl.TabIndex = 1;
            desBttn_dwnLbl.Text = "descendit";
            desBttn_dwnLbl.UseVisualStyleBackColor = true;
            desBttn_dwnLbl.Click += desBttn_dwnLbl_Click;
            // 
            // medBttn_cenLbl
            // 
            medBttn_cenLbl.Location = new Point(316, 0);
            medBttn_cenLbl.Name = "medBttn_cenLbl";
            medBttn_cenLbl.Size = new Size(94, 29);
            medBttn_cenLbl.TabIndex = 2;
            medBttn_cenLbl.Text = "medium";
            medBttn_cenLbl.UseVisualStyleBackColor = true;
            medBttn_cenLbl.Click += medBttn_cenLbl_Click;
            // 
            // LatinTranslator
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(medBttn_cenLbl);
            Controls.Add(desBttn_dwnLbl);
            Controls.Add(autBttn_upLbl);
            Name = "LatinTranslator";
            Text = "Latin Translator App";
            ResumeLayout(false);
        }

        #endregion

        private Button autBttn_upLbl;
        private Button desBttn_dwnLbl;
        private Button medBttn_cenLbl;
    }
}
